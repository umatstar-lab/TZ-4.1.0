<?php
/*------------------------------------------------------------------------
# Flipbook Gallery Addon for TZ Portfolio 4 / Joomla 6
-------------------------------------------------------------------------*/

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\Filesystem\File;
use TemPlaza\Component\TZ_Portfolio\Site\Helper\ArticleHelper;

$item = $this->item;
$params = $this->params;
$gallery = $this->flipbook_gallery;

$getParam = function($name, $default = null) {
    return method_exists($this, 'getFlipbookParam') ? $this->getFlipbookParam($name, $default) : $default;
};

if ((int) $getParam('mt_flipbook_gallery_show', 1) !== 1) {
    return;
}

if (!$item || !$gallery || !isset($gallery->data) || !is_array($gallery->data) || !count($gallery->data)) {
    return;
}

$articleId = isset($item->id) ? (int) $item->id : 0;
$uid = 'tz-flipbook-gallery-' . $articleId . '-' . substr(md5(uniqid('', true)), 0, 8);
$menuId = $uid . '-menu';

$showPageSelector = (int) $getParam('mt_flipbook_gallery_show_page_selector', 1);
$showCover = (int) $getParam('mt_flipbook_gallery_show_cover_page', 1);
$imageSize = $getParam('mt_flipbook_gallery_size', 'o') ?: 'o';

// Load frontend flipbook assets here too. When the add-on is rendered via the after-content hook,
// TZ Portfolio may not instantiate the add-on view early enough for the view asset loader to run.
try {
    $app = Factory::getApplication();
    $document = method_exists($app, 'getDocument') ? $app->getDocument() : null;

    if ($document && method_exists($document, 'getWebAssetManager')) {
        $wa = $document->getWebAssetManager();
        $base = Uri::root() . 'components/com_tz_portfolio/add-ons/mediatype/flipbook_gallery/';

        $registerStyle = function($name, $uri) use ($wa) {
            if (!method_exists($wa, 'assetExists') || !$wa->assetExists('style', $name)) {
                $wa->registerStyle($name, $uri, ['version' => '1.0.15']);
            }
            $wa->useStyle($name);
        };

        $registerScript = function($name, $uri, array $dependencies = ['jquery']) use ($wa) {
            if (!method_exists($wa, 'assetExists') || !$wa->assetExists('script', $name)) {
                $wa->registerScript($name, $uri, [], [], $dependencies);
            }
            $wa->useScript($name);
        };

        $registerStyle('com_tz_portfolio.addon.mediatype.flipbook_gallery', $base . 'css/style.css');
        $registerScript('com_tz_portfolio.addon.mediatype.flipbook_gallery.jquery-ui', $base . 'js/jquery-ui-1.10.4.min.js', ['jquery']);
        $registerScript('com_tz_portfolio.addon.mediatype.flipbook_gallery.easing', $base . 'js/jquery.easing.1.3.js', ['jquery']);
        $registerScript('com_tz_portfolio.addon.mediatype.flipbook_gallery.booklet', $base . 'js/jquery.booklet.latest.min.js', [
            'jquery',
            'com_tz_portfolio.addon.mediatype.flipbook_gallery.jquery-ui',
            'com_tz_portfolio.addon.mediatype.flipbook_gallery.easing'
        ]);
    }
} catch (\Throwable $e) {
    // Do not break article rendering because of asset registration.
}

$bookletOptions = [];
$bookletOptions[] = "hashTitleText: '" . addslashes(Text::_('PLG_MEDIATYPE_FLIPBOOK_GALLERY_PAGE')) . "'";
$bookletOptions[] = 'autoCenter: true';

$width = $getParam('mt_flipbook_gallery_width', '100%');
$height = $getParam('mt_flipbook_gallery_height', '');
$ratio = $getParam('mt_flipbook_gallery_ratio', '5:3');
$direction = $getParam('mt_flipbook_gallery_direction', 'LTR');
$paddingPage = $getParam('mt_flipbook_gallery_padding', '2vw');
$arrows = (int) $getParam('mt_flipbook_gallery_show_arrow', 1);

if ($width) {
    $bookletOptions[] = "width: '" . addslashes((string) $width) . "'";
}
if ($height) {
    $bookletOptions[] = "height: '" . addslashes((string) $height) . "'";
}
if ($ratio && strpos((string) $ratio, ':') !== false) {
    [$rwidth, $rheight] = explode(':', (string) $ratio, 2);
    $rwidth = (int) $rwidth;
    $rheight = (int) $rheight;
    if ($rwidth && $rheight) {
        $bookletOptions[] = "rwidth: {$rwidth}";
        $bookletOptions[] = "rheight: {$rheight}";
    }
}
if ($direction) {
    $bookletOptions[] = "direction: '" . addslashes((string) $direction) . "'";
}
if ($paddingPage) {
    $bookletOptions[] = "pagePadding: '" . addslashes((string) $paddingPage) . "'";
}
if ($arrows) {
    $bookletOptions[] = 'arrows: true';
}
if ($showPageSelector) {
    $bookletOptions[] = "menu: '#" . addslashes($menuId) . "'";
    $bookletOptions[] = 'pageSelector: true';
}

echo '<div class="tz-flipbook-gallery-wrap">';
if ($showPageSelector) {
    echo '<div id="' . htmlspecialchars($menuId, ENT_COMPAT, 'UTF-8') . '" class="flipbook-gallery-menu"></div>';
}
echo '<div class="tz-flipbook-gallery-shell">';
echo '<div id="' . htmlspecialchars($uid, ENT_COMPAT, 'UTF-8') . '" class="tz_portfolio_flipbook_gallery tz_portfolio_plus_flipbook_gallery">';

if ($showCover) : ?>
    <div class="gallery-listing" title="<?php echo htmlspecialchars($item->title, ENT_COMPAT, 'UTF-8'); ?>">
        <div class="gallery-start">
            <h2><?php echo htmlspecialchars($item->title, ENT_COMPAT, 'UTF-8'); ?></h2>
        </div>
    </div>
<?php endif;

for ($i = 0; $i < count($gallery->data); $i++) {
    $image = basename((string) $gallery->data[$i]);
    if ($image === '') {
        continue;
    }

    $caption = isset($gallery->title[$i]) ? (string) $gallery->title[$i] : '';
    $basePathNew = 'images/tz_portfolio/flipbook_gallery/' . $articleId . '/';
    $basePathLegacy = 'images/tz_portfolio_plus/flipbook_gallery/' . $articleId . '/';
    $basePath = File::exists(JPATH_ROOT . '/' . $basePathNew . $image) ? $basePathNew : $basePathLegacy;
    $original = $basePath . $image;

    if ($imageSize !== 'o') {
        $thumb = $basePath . 'resize/' . File::stripExt($image) . '_' . $imageSize . '.' . File::getExt($image);
        if (!File::exists(JPATH_ROOT . '/' . $thumb)) {
            $thumb = $original;
        }
    } else {
        $thumb = $original;
    }

    $thumb = ArticleHelper::convertImageLegacy($thumb);
    ?>
    <div class="gallery-listing"<?php echo $caption ? ' title="' . htmlspecialchars($caption, ENT_COMPAT, 'UTF-8') . '"' : ''; ?>>
        <div class="gallery-image">
            <img src="<?php echo $thumb; ?>" alt="<?php echo htmlspecialchars($caption ?: $item->title, ENT_COMPAT, 'UTF-8'); ?>" />
        </div>
    </div>
    <?php
}

echo '</div>';
echo '</div>';
echo '</div>';

try {
    $document = Factory::getApplication()->getDocument();
    if ($document && method_exists($document, 'getWebAssetManager')) {
        $wa = $document->getWebAssetManager();
        $wa->addInlineScript("jQuery(function(\$){\n"
            . "function initFlipbookGallery" . preg_replace('/[^a-zA-Z0-9_]/', '_', $uid) . "(){\n"
            . "var \$book = \$('#" . addslashes($uid) . "');\n"
            . "if (!\$book.length || \$book.hasClass('tz-flipbook-initialized')) { return; }\n"
            . "if (!\$.fn.booklet) { window.setTimeout(initFlipbookGallery" . preg_replace('/[^a-zA-Z0-9_]/', '_', $uid) . ", 300); return; }\n"
            . "var \$wrap = \$book.closest('.tz-flipbook-gallery-wrap'); var \$scope = \$book.closest('.tp-item-page, .item-page, article, .com-content-article'); if (!\$scope.length) { \$scope = \$book.closest('main, #content, .container, body'); } var \$content = \$scope.find('.tpp-item-fulltext, .itemFullText, .item-fulltext, .com-content-article__body, .articleBody').last(); if (!\$content.length) { \$content = \$scope.find('.tpp-item-introtext, .itemIntroText, .item-introtext').last(); } if (\$content.length && !\$wrap.data('tzMovedAfterContent')) { \$wrap.insertAfter(\$content); \$wrap.data('tzMovedAfterContent', true); }\n"
            . "\$book.addClass('tz-flipbook-initialized').booklet({" . implode(',', $bookletOptions) . "});\n"
            . "}\n"
            . "\$(document).ready(initFlipbookGallery" . preg_replace('/[^a-zA-Z0-9_]/', '_', $uid) . ");\n"
            . "\$(window).on('load', initFlipbookGallery" . preg_replace('/[^a-zA-Z0-9_]/', '_', $uid) . ");\n"
            . "});");
    }
} catch (\Throwable $e) {
    echo '<script>jQuery(function($){var init=function(){var $book=$("#' . addslashes($uid) . '");if(!$book.length||$book.hasClass("tz-flipbook-initialized")){return;}if(!$.fn.booklet){setTimeout(init,300);return;}var $wrap=$book.closest(".tz-flipbook-gallery-wrap"),$scope=$book.closest(".tp-item-page, .item-page, article, .com-content-article");if(!$scope.length){$scope=$book.closest("main, #content, .container, body");}var $content=$scope.find(".tpp-item-fulltext, .itemFullText, .item-fulltext, .com-content-article__body, .articleBody").last();if(!$content.length){$content=$scope.find(".tpp-item-introtext, .itemIntroText, .item-introtext").last();}if($content.length&&!$wrap.data("tzMovedAfterContent")){$wrap.insertAfter($content);$wrap.data("tzMovedAfterContent",true);}$book.addClass("tz-flipbook-initialized").booklet({' . implode(',', $bookletOptions) . '});};$(init);$(window).on("load",init);});</script>';
}

