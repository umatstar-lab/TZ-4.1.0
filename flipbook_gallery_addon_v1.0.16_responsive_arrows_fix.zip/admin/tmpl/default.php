<?php
/*------------------------------------------------------------------------
# Flipbook Gallery Addon for TZ Portfolio 4 / Joomla 6
-------------------------------------------------------------------------*/

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\Filesystem\File;
use TemPlaza\Component\TZ_Portfolio\Administrator\Library\Helper\AddonHelper;

$flipbook_gallery = null;

if ($this->item && isset($this->item->media)) {
    $media = $this->item->media;
    if (is_string($media)) {
        $tmp = json_decode($media);
        $media = $tmp ?: null;
    }

    if (is_object($media) && isset($media->flipbook_gallery)) {
        $flipbook_gallery = $media->flipbook_gallery;
    } elseif (is_array($media) && isset($media['flipbook_gallery'])) {
        $flipbook_gallery = $media['flipbook_gallery'];
    }
}

$flipbook_gallery_tmp = uniqid('flipbook_gallery_');
$params = $this->params;
$types = $params ? $params->get('flipbook_gallery_file_type', 'bmp,gif,jpg,jpeg,png') : 'bmp,gif,jpg,jpeg,png';
$types = array_map('trim', explode(',', $types));
$types = array_filter($types);
$types = array_map(fn($type) => '"' . $type . '"', $types);
$types = implode(',', $types);
$article_id = $this->item && isset($this->item->id) ? (int) $this->item->id : 0;

$app = Factory::getApplication();
$document = method_exists($app, 'getDocument') ? $app->getDocument() : null;

// Joomla 6: load assets explicitly and safely. If WebAsset registration is not available
// at this render stage, direct addScript/addStyleSheet keeps the uploader alive.
if ($document) {
    HTMLHelper::_('jquery.framework');

    $root = rtrim(Uri::root(), '/') . '/';
    $addonBase = $root . 'components/com_tz_portfolio/add-ons/mediatype/flipbook_gallery/';
    $mediaBase = $root . 'media/com_tz_portfolio/';

    if (method_exists($document, 'addStyleSheet')) {
        $document->addStyleSheet($mediaBase . 'css/jquery.dm-uploader.min.css');
        $document->addStyleSheet($addonBase . 'admin/css/style.css');
    }

    if (method_exists($document, 'addScript')) {
        $document->addScript($mediaBase . 'js/jquery.dm-uploader.min.js');
    }
}

$addon = AddonHelper::getAddOn('mediatype', 'flipbook_gallery');
$addon_id = $addon && isset($addon->id) ? (int) $addon->id : 0;

if ($app->isClient('administrator')) {
    $ajaxUrl = 'index.php?option=com_tz_portfolio&view=addon_datas&addon_id=' . $addon_id . '&addon_task=gallery.ajax&folder=' . $flipbook_gallery_tmp;
} else {
    $input = $app->input;
    $id = $input->getInt('a_id', 0);
    $editUrl = $id ? '&layout=edit&id=' . $id : '';
    $ajaxUrl = 'index.php?option=com_tz_portfolio&view=addon&addon_task=gallery.ajax&addon_id=' . $addon_id . '&folder=' . $flipbook_gallery_tmp . $editUrl;
}

if ($document) {
    $document->addScriptDeclaration('
var FlipbookGallery = window.FlipbookGallery || {};
jQuery.extend(FlipbookGallery, {
    ajaxUrl: "' . $ajaxUrl . '",
    maxFileSize: ' . (int) ($params ? $params->get('flipbook_gallery_file_size', 10) : 10) . ',
    extFilter: [' . $types . ']
});
');
}

if ($document && method_exists($document, 'addScript')) {
    $root = rtrim(Uri::root(), '/') . '/';
    $addonBase = $root . 'components/com_tz_portfolio/add-ons/mediatype/flipbook_gallery/';
    // style-ui must be loaded before uploader. Uploader has a native fallback if dmUploader is missing.
    $document->addScript($addonBase . 'admin/js/style-ui.js');
    $document->addScript($addonBase . 'admin/js/flipbook_gallery_uploader.js');
}

$data = [];
$titles = [];
$featured = '';

if (is_object($flipbook_gallery)) {
    $data = isset($flipbook_gallery->data) && is_array($flipbook_gallery->data) ? $flipbook_gallery->data : [];
    $titles = isset($flipbook_gallery->title) && is_array($flipbook_gallery->title) ? $flipbook_gallery->title : [];
    $featured = isset($flipbook_gallery->featured) ? $flipbook_gallery->featured : '';
} elseif (is_array($flipbook_gallery)) {
    $data = isset($flipbook_gallery['data']) && is_array($flipbook_gallery['data']) ? $flipbook_gallery['data'] : [];
    $titles = isset($flipbook_gallery['title']) && is_array($flipbook_gallery['title']) ? $flipbook_gallery['title'] : [];
    $featured = isset($flipbook_gallery['featured']) ? $flipbook_gallery['featured'] : '';
}
?>

<div id="tp-add-on__<?php echo $this->_type . '-' . $this->_name; ?>" class="addon-tab">
    <div class="container-addon">
        <div class="row-addon">
            <div class="col-addon">
                <div id="flipbook_gallery_uploader" class="dm-uploader p-5">
                    <h3 class="mb-5 mt-5 text-muted"><?php echo Text::_('PLG_MEDIATYPE_FLIPBOOK_GALLERY_DROP_DRAG'); ?></h3>
                    <div class="btn btn-primary btn-block mb-5">
                        <span><?php echo Text::_('PLG_MEDIATYPE_FLIPBOOK_GALLERY_OPEN_FILE'); ?></span>
                        <input type="file" title="Click to add Files" accept="image/*" multiple="multiple" />
                    </div>
                </div>
            </div>
            <div class="col-addon">
                <div class="card h-100">
                    <div class="card-header"><?php echo Text::_('PLG_MEDIATYPE_FLIPBOOK_GALLERY_FILE_LIST'); ?></div>
                    <ul class="list-unstyled p-2 d-flex flex-column col" id="flipbook_gallery_files">
                        <?php for ($i = 0; $i < count($data); $i++) :
                            $flipbook_image = basename((string) $data[$i]);
                            $flipbook_title = isset($titles[$i]) ? (string) $titles[$i] : '';
                            $basePathNew = 'images/tz_portfolio/flipbook_gallery/' . $article_id . '/';
                            $basePathLegacy = 'images/tz_portfolio_plus/flipbook_gallery/' . $article_id . '/';
                            $basePath = File::exists(JPATH_ROOT . '/' . $basePathNew . $flipbook_image) ? $basePathNew : $basePathLegacy;
                            ?>
                            <li class="media" data-name="<?php echo htmlspecialchars($flipbook_image, ENT_COMPAT, 'UTF-8'); ?>" data-source="server">
                                <img class="mr-3 mb-2 preview-img" src="<?php echo Uri::root() . $basePath . $flipbook_image; ?>" alt="">
                                <div class="media-body mb-1">
                                    <p class="mb-2">
                                        <strong class="filename"><?php echo htmlspecialchars($flipbook_image, ENT_COMPAT, 'UTF-8'); ?></strong> - Status: <span class="status text-success">Available</span> - <em class="grid_featured"><input type="radio" name="flipbook_image_featured" class="flipbook_image_featured" value="<?php echo htmlspecialchars($flipbook_image, ENT_COMPAT, 'UTF-8'); ?>"<?php echo $featured == $flipbook_image ? ' checked="checked"' : ''; ?> /> <?php echo Text::_('JFEATURED'); ?></em> - <a href="#" class="delete_flipbook_image"><?php echo Text::_('JACTION_DELETE'); ?></a>
                                    </p>
                                    <p class="mb-2">
                                        <input type="text" class="inputbox" name="flipbook_gallery_image_title[]" placeholder="Title..." value="<?php echo htmlspecialchars($flipbook_title, ENT_COMPAT, 'UTF-8'); ?>" />
                                    </p>
                                    <div class="progress mb-2"><div class="progress-bar bg-primary bg-success" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div></div>
                                    <hr class="mt-1 mb-1" />
                                </div>
                                <input type="hidden" name="flipbook_gallery_image[]" class="flipbook_gallery_url" value="<?php echo htmlspecialchars($flipbook_image, ENT_COMPAT, 'UTF-8'); ?>" />
                                <input type="hidden" name="flipbook_gallery_source[]" class="flipbook_gallery_source" value="server" />
                            </li>
                        <?php endfor; ?>
                        <li class="text-muted text-center empty"<?php echo count($data) ? ' style="display: none;"' : ''; ?>><?php echo Text::_('PLG_MEDIATYPE_FLIPBOOK_GALLERY_NO_FILE_UPLOADED'); ?></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="row-addon">
            <div class="col-addon">
                <div class="card h-100">
                    <div class="card-header"><?php echo Text::_('PLG_MEDIATYPE_FLIPBOOK_GALLERY_DEBUG_MESSAGES'); ?></div>
                    <ul class="list-group list-group-flush" id="flipbook_gallery_debug">
                        <li class="list-group-item text-muted empty"><?php echo Text::_('PLG_MEDIATYPE_FLIPBOOK_GALLERY_LOADING_PLUGIN'); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <input type="hidden" name="flipbook_gallery_folder" id="flipbook_gallery_folder" value="<?php echo $flipbook_gallery_tmp; ?>" />
    <script type="text/html" id="flipbook_gallery_files_template">
        <li class="media">
            <img class="mr-3 mb-2 preview-img" src="https://via.placeholder.com/150" alt="">
            <div class="media-body mb-1">
                <p class="mb-2"><strong class="filename">%%filename%%</strong> - Status: <span class="text-muted">Waiting</span> - <em class="grid_featured"><input type="radio" name="flipbook_image_featured" class="flipbook_image_featured" value="" /> <?php echo Text::_('JFEATURED'); ?></em> - <a href="#" class="delete_flipbook_image"><?php echo Text::_('JACTION_DELETE'); ?></a></p>
                <p class="mb-2"><input type="text" class="inputbox" name="flipbook_gallery_image_title[]" placeholder="Title..." /></p>
                <div class="progress mb-2"><div class="progress-bar progress-bar-striped progress-bar-animated bg-primary" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div></div>
                <hr class="mt-1 mb-1" />
            </div>
            <input type="hidden" name="flipbook_gallery_image[]" class="flipbook_gallery_url" value="" />
            <input type="hidden" name="flipbook_gallery_source[]" class="flipbook_gallery_source" value="client" />
        </li>
    </script>
    <script type="text/html" id="flipbook_gallery_debug_template">
        <li class="list-group-item text-%%color%%"><strong>%%date%%</strong>: %%message%%</li>
    </script>
</div>
