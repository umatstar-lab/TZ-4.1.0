<?php
/*------------------------------------------------------------------------
# Flipbook Gallery Addon for TZ Portfolio 4 / Joomla 6
-------------------------------------------------------------------------*/

namespace TemPlaza\Component\TZ_Portfolio\AddOn\Mediatype\Flipbook_gallery\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\Filesystem\File;
use Joomla\Filesystem\Folder;
use TemPlaza\Component\TZ_Portfolio\Administrator\Library\AddOn\AddOnAdminModel;

class Flipbook_galleryModel extends AddOnAdminModel
{
    public function save($data)
    {
        $app = Factory::getApplication();
        $input = $app->input;
        $params = $this->getState('params');

        $tmpFolder = $input->get('flipbook_gallery_folder', '', 'cmd');
        $flipbookImages = $input->get('flipbook_gallery_image', [], 'array');
        $flipbookSource = $input->get('flipbook_gallery_source', [], 'array');
        $flipbookTitle = $input->get('flipbook_gallery_image_title', [], 'array');
        $featuredImage = $input->get('flipbook_image_featured', '', 'string');

        $articleId = is_object($data) && isset($data->id) ? (int) $data->id : 0;
        if (!$articleId) {
            return;
        }

        $config = Factory::getApplication()->getConfig();
        $tmpPart = $tmpFolder ? $config->get('tmp_path') . '/' . $tmpFolder : '';
        $tmpDest = JPATH_ROOT . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR
            . 'tz_portfolio' . DIRECTORY_SEPARATOR . 'flipbook_gallery';

        $arrServer = [];
        $arrClient = [];

        for ($i = 0; $i < count($flipbookSource); $i++) {
            $img = isset($flipbookImages[$i]) ? basename((string) $flipbookImages[$i]) : '';
            if ($img === '') {
                continue;
            }

            $row = new \stdClass();
            $row->image = $img;
            $row->title = isset($flipbookTitle[$i]) ? (string) $flipbookTitle[$i] : '';

            if ($flipbookSource[$i] === 'server') {
                $arrServer[] = $row;
            } elseif ($flipbookSource[$i] === 'client') {
                $arrClient[] = $row;
            }
        }

        $imageSize = $params ? $params->get('flipbook_gallery_size') : [];
        if ($imageSize && !is_array($imageSize) && preg_match_all('/(\{.*?\})/', $imageSize, $match)) {
            $imageSize = $match[1];
        }

        $articleFolder = $tmpDest . DIRECTORY_SEPARATOR . $articleId;
        if ((count($arrClient) || count($arrServer)) && !Folder::exists($articleFolder)) {
            Folder::create($articleFolder);
        }

        if ($input->getCmd('task') === 'save2copy' && $input->getInt('id')) {
            $oldId = $input->getInt('id');
            $oldFolder = $tmpDest . DIRECTORY_SEPARATOR . $oldId;
            if (!Folder::exists($oldFolder)) {
                $oldFolder = JPATH_ROOT . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR
                    . 'tz_portfolio_plus' . DIRECTORY_SEPARATOR . 'flipbook_gallery' . DIRECTORY_SEPARATOR . $oldId;
            }
            if (Folder::exists($oldFolder)) {
                Folder::copy($oldFolder, $articleId, $tmpDest, true);
            }
        }

        if (Folder::exists($articleFolder)) {
            $imgServer = Folder::files($articleFolder, '.', false, false);
            foreach ($imgServer as $img) {
                $keep = false;
                foreach ($arrServer as $server) {
                    if ($server->image === $img) {
                        $keep = true;
                        break;
                    }
                }

                if (!$keep && !in_array($img, array_column($arrClient, 'image'), true)) {
                    $path = $articleFolder . DIRECTORY_SEPARATOR . $img;
                    if (File::exists($path)) {
                        File::delete($path);
                    }

                    if (is_array($imageSize)) {
                        foreach ($imageSize as $_size) {
                            $size = json_decode($_size);
                            if (!$size || empty($size->image_name_prefix)) {
                                continue;
                            }
                            $resizePath = $articleFolder . DIRECTORY_SEPARATOR . 'resize' . DIRECTORY_SEPARATOR
                                . File::stripExt($img)
                                . '_' . $size->image_name_prefix . '.' . File::getExt($img);
                            if (File::exists($resizePath)) {
                                File::delete($resizePath);
                            }
                        }
                    }
                }
            }
        }

        foreach ($arrClient as $client) {
            if (!$tmpPart) {
                continue;
            }

            if (File::exists($tmpPart . DIRECTORY_SEPARATOR . $client->image)) {
                File::move($tmpPart . DIRECTORY_SEPARATOR . $client->image, $articleFolder . DIRECTORY_SEPARATOR . $client->image);
            }

            if (!Folder::exists($articleFolder . DIRECTORY_SEPARATOR . 'resize')) {
                Folder::create($articleFolder . DIRECTORY_SEPARATOR . 'resize');
            }

            if (is_array($imageSize)) {
                foreach ($imageSize as $_size) {
                    $size = json_decode($_size);
                    if (!$size || empty($size->image_name_prefix)) {
                        continue;
                    }
                    $tmpResizePath = $tmpPart . DIRECTORY_SEPARATOR . 'resize' . DIRECTORY_SEPARATOR
                        . File::stripExt($client->image)
                        . '_' . $size->image_name_prefix . '.' . File::getExt($client->image);
                    $resizePath = $articleFolder . DIRECTORY_SEPARATOR . 'resize' . DIRECTORY_SEPARATOR
                        . File::stripExt($client->image)
                        . '_' . $size->image_name_prefix . '.' . File::getExt($client->image);
                    if (File::exists($tmpResizePath)) {
                        File::move($tmpResizePath, $resizePath);
                    }
                }
            }
        }

        if ($tmpPart && Folder::exists($tmpPart)) {
            Folder::delete($tmpPart);
        }

        $imageData = [
            'data' => array_values(array_map('basename', $flipbookImages)),
            'title' => array_values($flipbookTitle),
            'featured' => basename((string) $featuredImage),
        ];

        $this->__save($data, $imageData);
    }

    public function delete(&$article)
    {
        if (is_object($article) && !empty($article->id)) {
            $base = JPATH_ROOT . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR
                . 'tz_portfolio' . DIRECTORY_SEPARATOR . 'flipbook_gallery' . DIRECTORY_SEPARATOR . (int) $article->id;
            if (Folder::exists($base)) {
                Folder::delete($base);
            }
        }
    }
}
