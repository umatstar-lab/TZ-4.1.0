<?php
/*------------------------------------------------------------------------
# Flipbook Gallery Addon for TZ Portfolio 4 / Joomla 6
-------------------------------------------------------------------------*/

namespace TemPlaza\Component\TZ_Portfolio\AddOn\Mediatype\Flipbook_gallery\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Application\ApplicationHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Image\Image;
use Joomla\Filesystem\File;
use Joomla\Filesystem\Folder;
use Joomla\Registry\Registry;
use TemPlaza\Component\TZ_Portfolio\Administrator\Library\AddOn\AddOnController;
use TemPlaza\Component\TZ_Portfolio\Administrator\Library\Helper\AddonHelper;

class GalleryController extends AddOnController
{
    public function ajax(): void
    {
        header('Content-Type: application/json');

        try {
            $app = Factory::getApplication();
            $input = $app->input;

            if (!$app->isClient('administrator') && $input->get('view') !== 'addon') {
                throw new \RuntimeException('You are not authorized!');
            }

            $userfile = $input->files->get('file', null, 'raw');
            $folder = $input->get('folder', '', 'cmd');

            if (!$folder || !isset($userfile['error']) || is_array($userfile['error'])) {
                throw new \RuntimeException('Invalid parameters.');
            }

            switch ($userfile['error']) {
                case UPLOAD_ERR_OK:
                    break;
                case UPLOAD_ERR_NO_FILE:
                    throw new \RuntimeException('No file sent.');
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    throw new \RuntimeException('Exceeded filesize limit.');
                default:
                    throw new \RuntimeException('Unknown upload error.');
            }

            $filename = ApplicationHelper::stringURLSafe(File::stripExt($userfile['name'])) . '.' . File::getExt($userfile['name']);
            $config = Factory::getApplication()->getConfig();
            $tmpFolder = $config->get('tmp_path') . '/' . $folder;
            $tmpDest = $tmpFolder . '/' . $filename;
            $tmpResizeFolder = $tmpFolder . '/resize';

            if (!Folder::exists($tmpFolder)) {
                Folder::create($tmpFolder);
            }

            if (!File::upload($userfile['tmp_name'], $tmpDest)) {
                throw new \RuntimeException('Failed to move uploaded file.');
            }

            if (!Folder::exists($tmpResizeFolder) && !Folder::create($tmpResizeFolder)) {
                throw new \RuntimeException('Failed to create resize folder.');
            }

            $addon = AddonHelper::getAddOn('mediatype', 'flipbook_gallery');
            $params = new Registry($addon ? $addon->params : null);
            $imageSize = $params->get('flipbook_gallery_size');

            if ($imageSize && !is_array($imageSize) && preg_match_all('/(\{.*?\})/', $imageSize, $match)) {
                $imageSize = $match[1];
            }

            if (is_array($imageSize) && count($imageSize)) {
                $image = new Image();
                $image->loadFile($tmpDest);
                $imageProperties = $image->getImageFileProperties($tmpDest);

                foreach ($imageSize as $_size) {
                    $size = json_decode($_size);

                    if (!$size || empty($size->width) || empty($size->image_name_prefix)) {
                        continue;
                    }

                    $newPath = $tmpResizeFolder . DIRECTORY_SEPARATOR
                        . File::stripExt($filename)
                        . '_' . $size->image_name_prefix . '.' . File::getExt($filename);

                    $newH = ($imageProperties->height * (int) $size->width) / max(1, $imageProperties->width);
                    $newImage = $image->resize((int) $size->width, (int) $newH);

                    if (File::exists($newPath)) {
                        File::delete($newPath);
                    }

                    if (!$newImage->toFile($newPath, $imageProperties->type)) {
                        throw new \RuntimeException('Failed to resize image.');
                    }
                }
            }

            echo json_encode(['status' => 'ok', 'name' => $filename]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }

        die();
    }

    public function delete(): void
    {
        header('Content-Type: application/json');

        try {
            $app = Factory::getApplication();
            $input = $app->input;

            if (!$app->isClient('administrator')) {
                throw new \RuntimeException('You are not authorized!');
            }

            $file = basename($input->get('file', '', 'string'));
            $source = $input->get('data_source', '', 'cmd');

            if (!$file || !$source) {
                throw new \RuntimeException('Invalid parameters.');
            }

            if ($source === 'client') {
                $folderName = $input->get('tmp_folder', '', 'cmd');
                $folder = Factory::getApplication()->getConfig()->get('tmp_path') . '/' . $folderName;
            } else {
                $articleId = $input->getInt('article_id', 0);
                if (!$articleId) {
                    throw new \RuntimeException('Invalid article id.');
                }
                $folder = JPATH_ROOT . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR
                    . 'tz_portfolio' . DIRECTORY_SEPARATOR . 'flipbook_gallery' . DIRECTORY_SEPARATOR . $articleId;

                if (!Folder::exists($folder)) {
                    $folder = JPATH_ROOT . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR
                        . 'tz_portfolio_plus' . DIRECTORY_SEPARATOR . 'flipbook_gallery' . DIRECTORY_SEPARATOR . $articleId;
                }
            }

            $filePath = $folder . DIRECTORY_SEPARATOR . $file;
            if (File::exists($filePath) && !File::delete($filePath)) {
                throw new \RuntimeException('Failed to delete file.');
            }

            $addon = AddonHelper::getAddOn('mediatype', 'flipbook_gallery');
            $params = new Registry($addon ? $addon->params : null);
            $imageSize = $params->get('flipbook_gallery_size');

            if ($imageSize && !is_array($imageSize) && preg_match_all('/(\{.*?\})/', $imageSize, $match)) {
                $imageSize = $match[1];
            }

            if (is_array($imageSize)) {
                foreach ($imageSize as $_size) {
                    $size = json_decode($_size);
                    if (!$size || empty($size->image_name_prefix)) {
                        continue;
                    }
                    $resize = $folder . DIRECTORY_SEPARATOR . 'resize' . DIRECTORY_SEPARATOR
                        . File::stripExt($file)
                        . '_' . $size->image_name_prefix . '.' . File::getExt($file);
                    if (File::exists($resize)) {
                        File::delete($resize);
                    }
                }
            }

            echo json_encode(['status' => 'ok', 'name' => $file]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }

        die();
    }
}
