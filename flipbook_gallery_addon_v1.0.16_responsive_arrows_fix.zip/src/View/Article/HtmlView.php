<?php
/*------------------------------------------------------------------------
# Flipbook Gallery Addon for TZ Portfolio 4 / Joomla 6
-------------------------------------------------------------------------*/

namespace TemPlaza\Component\TZ_Portfolio\AddOn\Mediatype\Flipbook_gallery\Site\View\Article;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\Registry\Registry;

class HtmlView extends BaseHtmlView
{
    protected $item = null;
    protected $params = null;
    protected $addon_params = null;
    protected $flipbook_gallery = null;

    public function display($tpl = null)
    {
        $state = $this->get('State');
        $this->params = $state ? $state->get('params') : new Registry();
        $this->item = $this->get('Item');

        $model = $this->getModel();
        $addon = $model && method_exists($model, 'getAddon') ? $model->getAddon() : null;
        $this->addon_params = ($addon && isset($addon->params)) ? new Registry($addon->params) : new Registry();

        if ($this->item && isset($this->item->media) && isset($this->item->media->flipbook_gallery)) {
            $this->flipbook_gallery = clone $this->item->media->flipbook_gallery;
            $this->initAssets();
        }

        parent::display($tpl);
    }

    public function getFlipbookParam($name, $default = null)
    {
        $value = null;

        if ($this->params) {
            $value = $this->params->get($name, null);
        }

        if (($value === '' || $value === null) && $this->addon_params) {
            $value = $this->addon_params->get($name, $default);
        }

        return ($value === '' || $value === null) ? $default : $value;
    }

    protected function initAssets(): void
    {
        $app = Factory::getApplication();
        $document = method_exists($app, 'getDocument') ? $app->getDocument() : null;

        if (!$document || !method_exists($document, 'getWebAssetManager')) {
            return;
        }

        $wa = $document->getWebAssetManager();

        if (!$wa) {
            return;
        }

        foreach ([
            'com_tz_portfolio.addon.mediatype.flipbook_gallery',
        ] as $style) {
            if (!method_exists($wa, 'assetExists') || $wa->assetExists('style', $style)) {
                $wa->useStyle($style);
            }
        }

        foreach ([
            'com_tz_portfolio.addon.mediatype.flipbook_gallery.jquery-ui',
            'com_tz_portfolio.addon.mediatype.flipbook_gallery.easing',
            'com_tz_portfolio.addon.mediatype.flipbook_gallery.booklet',
        ] as $script) {
            if (!method_exists($wa, 'assetExists') || $wa->assetExists('script', $script)) {
                $wa->useScript($script);
            }
        }

        // The template initializes each uniquely identified book once, with its
        // own page menu. A second global initialization destroys that instance.
    }
}
