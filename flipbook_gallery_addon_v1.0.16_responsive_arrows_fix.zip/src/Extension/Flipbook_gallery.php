<?php
/*------------------------------------------------------------------------
# Flipbook Gallery Addon for TZ Portfolio 4 / Joomla 6
-------------------------------------------------------------------------*/

namespace TemPlaza\Component\TZ_Portfolio\AddOn\Mediatype\Flipbook_gallery\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use Psr\Container\ContainerInterface;
use TemPlaza\Component\TZ_Portfolio\Administrator\Library\AddOn\AddOn;

class Flipbook_gallery extends AddOn
{
    protected $autoloadLanguage = true;

    /** @var array<string,bool> */
    protected array $renderedFlipbooks = [];

    public function boot(ContainerInterface $container)
    {
        parent::boot($container);
        $this->registerAssets();
    }

    /** Keep this add-on visible in TZ Portfolio media type list. */
    public function onAddMediaType()
    {
        return parent::onAddMediaType();
    }

    public function onContentPrepareForm($form, $data)
    {
        return parent::onContentPrepareForm($form, $data);
    }

    public function onMediaTypeDisplayArticleForm($data = null)
    {
        return parent::onMediaTypeDisplayArticleForm($data);
    }

    private function registerAssets(): void
    {
        $app = Factory::getApplication();

        if (!method_exists($app, 'getDocument')) {
            return;
        }

        try {
            $document = $app->getDocument();
        } catch (\Throwable $e) {
            return;
        }

        if (!$document || !method_exists($document, 'getWebAssetManager')) {
            return;
        }

        $wa = $document->getWebAssetManager();

        if (!$wa) {
            return;
        }

        $base = Uri::root() . 'components/com_tz_portfolio/add-ons/mediatype/flipbook_gallery/';
        $mediaBase = Uri::root() . 'media/com_tz_portfolio/';

        $assets = [
            ['style',  'com_tz_portfolio.addon.mediatype.flipbook_gallery', $base . 'css/style.css'],
            ['style',  'com_tz_portfolio.addon.mediatype.flipbook_gallery.admin', $base . 'admin/css/style.css'],
            ['style',  'com_tz_portfolio.jquery.dm-uploader', $mediaBase . 'css/jquery.dm-uploader.min.css'],
            ['script', 'com_tz_portfolio.jquery.dm-uploader', $mediaBase . 'js/jquery.dm-uploader.min.js', ['jquery']],
            ['script', 'com_tz_portfolio.addon.mediatype.flipbook_gallery.jquery-ui', $base . 'js/jquery-ui-1.10.4.min.js', ['jquery']],
            ['script', 'com_tz_portfolio.addon.mediatype.flipbook_gallery.easing', $base . 'js/jquery.easing.1.3.js', ['jquery']],
            ['script', 'com_tz_portfolio.addon.mediatype.flipbook_gallery.booklet', $base . 'js/jquery.booklet.latest.min.js', ['jquery', 'com_tz_portfolio.addon.mediatype.flipbook_gallery.jquery-ui', 'com_tz_portfolio.addon.mediatype.flipbook_gallery.easing']],
            ['script', 'com_tz_portfolio.addon.mediatype.flipbook_gallery.style-ui', $base . 'admin/js/style-ui.js', ['jquery']],
            ['script', 'com_tz_portfolio.addon.mediatype.flipbook_gallery.uploader', $base . 'admin/js/flipbook_gallery_uploader.js', ['jquery']],
        ];

        foreach ($assets as $asset) {
            [$type, $name, $uri] = $asset;
            $dependencies = $asset[3] ?? [];

            if (method_exists($wa, 'assetExists') && $wa->assetExists($type, $name)) {
                continue;
            }

            if ($type === 'style') {
                $wa->registerStyle($name, $uri, ['version' => '1.0.16']);
            } else {
                $wa->registerScript($name, $uri, ['version' => '1.0.16'], [], $dependencies);
            }
        }
    }

    /**
     * TZ 4.1's single-layout builder renders media through this event.
     * The article-view event is optional and is not dispatched in builder mode.
     * Keep that event as a fallback; renderFlipbook prevents duplicate output.
     */
    public function onContentDisplayMediaType($context, &$article, $params, $page = 0, $layout = 'default')
    {
        if ($context !== 'com_tz_portfolio.article' || !is_object($article)
            || ($article->type ?? '') !== 'flipbook_gallery') {
            return null;
        }

        return $this->renderFlipbook($context, $article, $params, $page, $layout ?: 'default');
    }

    /**
     * Do not render via addition-info hook.
     * In TZ Portfolio article layout afterDisplayAdditionInfo is printed before intro/full text.
     */
    public function onAfterDisplayAdditionInfo($context, &$article, $params, $page = 0, $layout = 'default', $module = null)
    {
        return null;
    }

    /**
     * Render the flipbook after main article content.
     * TZ Portfolio article template prints contentDisplayArticleView after introtext/fulltext.
     */
    public function onContentDisplayArticleView($context, &$article, $params, $page = 0, $layout = 'default')
    {
        if ($context !== 'com_tz_portfolio.article') {
            return null;
        }

        return $this->renderFlipbook($context, $article, $params, $page, $layout ?: 'default');
    }

    private function renderFlipbook($context, &$article, $params, $page = 0, $layout = 'default')
    {
        if (!$article) {
            return null;
        }

        $gallery = null;
        if (isset($article->media) && isset($article->media->flipbook_gallery)) {
            $gallery = clone $article->media->flipbook_gallery;
            $this->setVariable('flipbook_gallery', $gallery);
        }

        if (!$gallery || !isset($gallery->data) || !is_array($gallery->data) || !count($gallery->data)) {
            return null;
        }

        $this->setVariable('item', $article);

        $articleId = isset($article->id) ? (int) $article->id : 0;
        $key = md5((string) $context . ':' . $articleId . ':' . (string) $layout);

        if (isset($this->renderedFlipbooks[$key])) {
            return null;
        }

        try {
            $html = $this->_getViewHtml($context, $article, $params, $layout ?: 'default');
        } catch (\Throwable $e) {
            $html = null;
        }

        if ($html) {
            $this->renderedFlipbooks[$key] = true;
            return $html;
        }

        return null;
    }
}
