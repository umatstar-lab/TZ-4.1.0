(function ($, window) {
    "use strict";
    // Component tours are available on request only; never open on page load.
    window.tppIntroGuide = function (view, steps, stripped, token) {
        if (typeof introJs === "undefined" || !steps) {
            return;
        }
        var guide = introJs();
        guide.addSteps(steps);
        guide.onbeforechange(function () {
            $(this._targetElement).addClass("tpp-intro-guide__loaded");
        });
        guide.onbeforeexit(function () {
            $(this._targetElement).removeClass("tpp-intro-guide__loaded");
        });
        guide.onexit(function () {
            $(this._targetElement).removeClass("tpp-intro-guide__loaded");
        });
        $("#toolbar-support").show().off("click.tppIntroGuide").on("click.tppIntroGuide", function (event) {
            event.preventDefault();
            guide.start();
        });
        return guide;
    };
})(jQuery, window);
