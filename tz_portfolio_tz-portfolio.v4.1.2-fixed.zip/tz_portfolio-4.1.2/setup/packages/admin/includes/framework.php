<?php
/*------------------------------------------------------------------------

# TZ Portfolio Extension

# ------------------------------------------------------------------------

# author    Sonny

# copyright Copyright (C) 2015 templaza.com. All Rights Reserved.

# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL

# Websites: http://templaza.com

# Technical Support:  Forum - http://templaza.com/Forum

-------------------------------------------------------------------------*/

// No direct access
defined('_JEXEC') or die;
use Joomla\CMS\HTML\HTMLHelper;
// Require defines.php file
JLoader::import('com_tz_portfolio.includes.defines',JPATH_ADMINISTRATOR.'/components');

// Require tzportfolioplus file with some functions php
JLoader::import('com_tz_portfolio.libraries.tzportfolioplus',JPATH_ADMINISTRATOR.'/components');

// Require uri files
if(!class_exists('TZ_PortfolioUri')){
    JLoader::import('com_tz_portfolio.libraries.uri',JPATH_ADMINISTRATOR.DIRECTORY_SEPARATOR.'components');
}

HTMLHelper::addIncludePath(COM_TZ_PORTFOLIO_LIBRARIES.'/html');

tzportfolioplusimport('helper.toolbar');
tzportfolioplusimport('helper.acl');

tzportfolioplusimport('user.user');

// Register class TZ_PortfolioPluginHelper from folder libraries of TZ Portfolio Plus
tzportfolioplusimport('plugin.helper');

// Register class TZ_PortfolioExtraField from folder libraries of TZ Portfolio Plus
tzportfolioplusimport('fields.extrafield');

// Register class TZ_PortfolioDatabase from folder libraries of TZ Portfolio Plus
tzportfolioplusimport('database.database');

// Register class TZ_PortfolioModelDialogBase from libraries folder.
tzportfolioplusimport('model.dialog');

// Register class TZ_PortfolioModelRejectBase from libraries folder.
tzportfolioplusimport('model.reject');

/* Register class TZ_PortfolioModelAdmin from libraries folder. */
tzportfolioplusimport('model.adminlegacy');

// Register class TZ_PortfolioControllerRejectBase from libraries folder.
tzportfolioplusimport('controller.reject');


// Register class TZ_PortfolioControllerArticleBase from libraries folder.
tzportfolioplusimport('controller.article');

