<?php
/*------------------------------------------------------------------------

# TZ Portfolio Extension

# ------------------------------------------------------------------------

# Author:    Sonny

# Copyright: Copyright (C) 2011-2024 TZ Portfolio.com. All Rights Reserved.

# @License - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL

# Website: http://tzportfolio.com

# Technical Support:  Forum - https://github.com/templaza/tz_portfolio/issues/

# Family website: http://templaza.com

# Family Support: Forum - https://templaza.com/Forums.html

-------------------------------------------------------------------------*/

// no direct access
defined('_JEXEC') or die;

use Joomla\CMS\Layout\LayoutHelper;

$sidebar        = $displayData['sidebar'];
$gridColumn     = $displayData['gridColumn'];
$attribute      = isset($displayData['attribute'])?$displayData['attribute']:'';
$responsive     = isset($displayData['responsive'])?$displayData['responsive']:'';
$containerclass = isset($displayData['containerclass'])?$displayData['containerclass']:'j-main-container';
?>

<?php if (COM_TZ_PORTFOLIO_JVERSION_4_COMPARE) { ?>
<div class="<?php if ($sidebar && !empty($sidebar)) {
        echo $gridColumn?'col-md-'.$gridColumn.$responsive:'';
    } else { echo 'col-md-12'; }
?>"<?php echo $attribute;?>>
<?php } ?>

    <div id="j-main-container" class="<?php echo $containerclass;
    if (!empty($this->sidebar) &&
        !COM_TZ_PORTFOLIO_JVERSION_4_COMPARE) {
        echo $gridColumn?' span'.$gridColumn:'';
    } ?>">

    <?php
        // Display message update to pro (it only use for free version)
        echo LayoutHelper::render('message');
    ?>
