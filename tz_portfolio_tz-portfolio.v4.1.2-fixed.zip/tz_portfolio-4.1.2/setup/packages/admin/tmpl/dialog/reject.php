<?php
/*------------------------------------------------------------------------

# TZ Portfolio Extension

# ------------------------------------------------------------------------

# Author:    Sonny

# Copyright: Copyright (C) 2011-2024 TZ Portfolio.com. All Rights Reserved.

# @License - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL

# Website: http://tzportfolio.com

# Technical Support:  Forum - https://github.com/templaza/tz_portfolio/issues/

# Family website: http://templaza.com

# Family Support: Forum - https://templaza.com/Forums.html

-------------------------------------------------------------------------*/

// no direct access
defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;

$modalId    = 'tpp-myarticle__reject';
$cids       = $this -> state -> get('article.id', array());

ob_start();
?>
<form action="index.php?option=com_tz_portfolio" method="post" name="adminForm" class="adminForm tpp-dialog__reject">
    <?php echo $this -> formReject -> renderField('message'); ?>
    <?php echo $this -> formReject -> getInput('id'); ?>

    <?php if(count($cids)){
        foreach($cids as $cid){
        ?>
            <input type="hidden" name="cid[]" value="<?php echo $cid; ?>"/>
    <?php }
    } ?>

    <input type="hidden" name="component" value="com_tz_portfolio"/>
    <input type="hidden" name="task" value="reject.apply"/>
</form>
<?php
$html   = ob_get_contents();
ob_end_clean();

echo HTMLHelper::_(
    'bootstrap.renderModal',
    $modalId,
    array(
        'title'      => Text::_('COM_TZ_PORTFOLIO_REJECT_ARTICLE'),
        'width'      => '100%',
        'height'     => '500px',
        'modalWidth' => '40',
        'closeButton' => true,
        'class'       => 'tpp-dialog-modal',
        'footer'      => '<a class="btn btn-default" data-dismiss="modal" data-bs-dismiss="modal" href="javascript:void(0);">'
            . Text::_('JCANCEL') . '</a><a class="btn btn-primary" href="javascript:void(0);" data-submit-button>'
            . Text::_('COM_TZ_PORTFOLIO_PLUS_REJECT') . '</a>',
    ),
    $html
);
?>