<?php
/*------------------------------------------------------------------------
# Flipbook Gallery Addon for TZ Portfolio 4 / Joomla 6
-------------------------------------------------------------------------*/

defined('_JEXEC') or die;

// Legacy entry file kept for TZ Portfolio addon installer element detection and backward compatibility.
$__flipbookClass = '\\TemPlaza\\Component\\TZ_Portfolio\\AddOn\\Mediatype\\Flipbook_gallery\\Extension\\Flipbook_gallery';

if (!class_exists($__flipbookClass, false)) {
    $file = __DIR__ . '/src/Extension/Flipbook_gallery.php';
    if (is_file($file)) {
        require_once $file;
    }
}

if (!class_exists('PlgTZ_Portfolio_PlusMediaTypeFlipbook_Gallery', false)
    && class_exists($__flipbookClass)
) {
    class PlgTZ_Portfolio_PlusMediaTypeFlipbook_Gallery extends \TemPlaza\Component\TZ_Portfolio\AddOn\Mediatype\Flipbook_gallery\Extension\Flipbook_gallery
    {
    }
}
