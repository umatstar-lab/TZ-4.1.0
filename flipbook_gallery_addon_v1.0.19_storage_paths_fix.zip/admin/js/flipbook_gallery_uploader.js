jQuery(function($){
    "use strict";

    var uploadCounter = 0;

    function getErrorMessage(xhr, status, message) {
        var msg = message || status || 'Upload error';
        if (xhr && xhr.responseText) {
            try {
                var json = JSON.parse(xhr.responseText);
                if (json && json.message) {
                    msg = json.message;
                }
            } catch (e) {
                msg = xhr.responseText.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim() || msg;
            }
        }
        return msg;
    }

    function validateFile(file) {
        var maxSize = (parseInt(FlipbookGallery.maxFileSize || 10, 10) || 10) * 1000000;
        var extFilter = FlipbookGallery.extFilter || [];
        var ext = (file.name.split('.').pop() || '').toLowerCase();

        if (file.size && file.size > maxSize) {
            FlipbookGallery.ui_add_log('File \'' + file.name + '\' cannot be added: size excess limit', 'danger');
            return false;
        }

        if (extFilter.length && $.inArray(ext, extFilter) === -1) {
            FlipbookGallery.ui_add_log('File \'' + file.name + '\' cannot be added: extension invalid', 'danger');
            return false;
        }

        return true;
    }

    function uploadFileFallback(file) {
        if (!validateFile(file)) {
            return;
        }

        var id = ++uploadCounter;
        FlipbookGallery.ui_add_log('New file added #' + id);
        FlipbookGallery.ui_multi_add_file(id, file);
        FlipbookGallery.ui_add_log('Starting the upload of #' + id);
        FlipbookGallery.ui_multi_update_file_status(id, 'uploading', 'Uploading...');
        FlipbookGallery.ui_multi_update_file_progress(id, 0, '', true);

        var formData = new FormData();
        formData.append('file', file, file.name);

        $.ajax({
            url: FlipbookGallery.ajaxUrl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            xhr: function () {
                var xhr = $.ajaxSettings.xhr();
                if (xhr.upload) {
                    xhr.upload.addEventListener('progress', function (event) {
                        if (event.lengthComputable) {
                            var percent = Math.round((event.loaded / event.total) * 100);
                            FlipbookGallery.ui_multi_update_file_progress(id, percent);
                        }
                    }, false);
                }
                return xhr;
            }
        }).done(function (data) {
            if (data && data.status === 'ok') {
                FlipbookGallery.ui_add_log('Server Response for file #' + id + ': ' + JSON.stringify(data));
                FlipbookGallery.ui_add_log('Upload of file #' + id + ' COMPLETED', 'success');
                FlipbookGallery.ui_multi_update_file_data(id, data);
                FlipbookGallery.ui_multi_update_file_status(id, 'success', 'Upload Complete');
                FlipbookGallery.ui_multi_update_file_progress(id, 100, 'success', false);
            } else {
                var msg = data && data.message ? data.message : 'Upload error';
                FlipbookGallery.ui_multi_update_file_status(id, 'danger', msg);
                FlipbookGallery.ui_multi_update_file_progress(id, 0, 'danger', false);
                FlipbookGallery.ui_add_log(msg, 'danger');
            }
        }).fail(function (xhr, status, message) {
            var msg = getErrorMessage(xhr, status, message);
            FlipbookGallery.ui_multi_update_file_status(id, 'danger', msg);
            FlipbookGallery.ui_multi_update_file_progress(id, 0, 'danger', false);
            FlipbookGallery.ui_add_log(msg, 'danger');
        });
    }

    function bindFallbackUploader() {
        var $box = $('#flipbook_gallery_uploader');
        var $input = $box.find('input[type="file"]');

        $input.off('change.flipbookfallback').on('change.flipbookfallback', function () {
            var files = this.files || [];
            for (var i = 0; i < files.length; i++) {
                uploadFileFallback(files[i]);
            }
            this.value = '';
        });

        $box.off('dragenter.flipbookfallback dragover.flipbookfallback dragleave.flipbookfallback drop.flipbookfallback')
            .on('dragenter.flipbookfallback dragover.flipbookfallback', function (event) {
                event.preventDefault();
                event.stopPropagation();
                $box.addClass('active');
            })
            .on('dragleave.flipbookfallback', function (event) {
                event.preventDefault();
                event.stopPropagation();
                $box.removeClass('active');
            })
            .on('drop.flipbookfallback', function (event) {
                event.preventDefault();
                event.stopPropagation();
                $box.removeClass('active');
                var files = event.originalEvent.dataTransfer ? event.originalEvent.dataTransfer.files : [];
                for (var i = 0; i < files.length; i++) {
                    uploadFileFallback(files[i]);
                }
            });

        FlipbookGallery.ui_add_log('Fallback uploader initialized', 'info');
    }

    if (typeof FlipbookGallery === 'undefined') {
        return;
    }

    FlipbookGallery.initUploader();

    if ($.fn && typeof $.fn.dmUploader === 'function') {
        $('#flipbook_gallery_uploader').dmUploader({
            url: FlipbookGallery.ajaxUrl,
            maxFileSize: (parseInt(FlipbookGallery.maxFileSize || 10, 10) || 10) * 1000000,
            allowedTypes: 'image/*',
            extFilter: FlipbookGallery.extFilter || [],
            onDragEnter: function(){
                this.addClass('active');
            },
            onDragLeave: function(){
                this.removeClass('active');
            },
            onInit: function(){
                FlipbookGallery.ui_add_log('Uploader initialized', 'info');
            },
            onComplete: function(){
                FlipbookGallery.ui_add_log('All pending transfers finished');
            },
            onNewFile: function(id, file){
                FlipbookGallery.ui_add_log('New file added #' + id);
                FlipbookGallery.ui_multi_add_file(id, file);
            },
            onBeforeUpload: function(id){
                FlipbookGallery.ui_add_log('Starting the upload of #' + id);
                FlipbookGallery.ui_multi_update_file_status(id, 'uploading', 'Uploading...');
                FlipbookGallery.ui_multi_update_file_progress(id, 0, '', true);
            },
            onUploadCanceled: function(id) {
                FlipbookGallery.ui_multi_update_file_status(id, 'warning', 'Canceled by User');
                FlipbookGallery.ui_multi_update_file_progress(id, 0, 'warning', false);
            },
            onUploadProgress: function(id, percent){
                FlipbookGallery.ui_multi_update_file_progress(id, percent);
            },
            onUploadSuccess: function(id, data){
                FlipbookGallery.ui_add_log('Server Response for file #' + id + ': ' + JSON.stringify(data));
                if (data && data.status === 'ok') {
                    FlipbookGallery.ui_add_log('Upload of file #' + id + ' COMPLETED', 'success');
                    FlipbookGallery.ui_multi_update_file_data(id, data);
                    FlipbookGallery.ui_multi_update_file_status(id, 'success', 'Upload Complete');
                    FlipbookGallery.ui_multi_update_file_progress(id, 100, 'success', false);
                } else {
                    var msg = data && data.message ? data.message : 'Upload error';
                    FlipbookGallery.ui_multi_update_file_status(id, 'danger', msg);
                    FlipbookGallery.ui_multi_update_file_progress(id, 0, 'danger', false);
                    FlipbookGallery.ui_add_log(msg, 'danger');
                }
            },
            onUploadError: function(id, xhr, status, message){
                var msg = getErrorMessage(xhr, status, message);
                FlipbookGallery.ui_multi_update_file_status(id, 'danger', msg);
                FlipbookGallery.ui_multi_update_file_progress(id, 0, 'danger', false);
                FlipbookGallery.ui_add_log(msg, 'danger');
            },
            onFallbackMode: function(){
                bindFallbackUploader();
            },
            onFileSizeError: function(file){
                FlipbookGallery.ui_add_log('File \'' + file.name + '\' cannot be added: size excess limit', 'danger');
            },
            onFileExtError: function(file){
                FlipbookGallery.ui_add_log('File \'' + file.name + '\' cannot be added: extension invalid', 'danger');
            }
        });
    } else {
        bindFallbackUploader();
    }
});
