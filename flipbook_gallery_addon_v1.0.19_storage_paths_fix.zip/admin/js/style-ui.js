/**
 * Style UI for Flipbook Gallery Uploader
 * Joomla 6 compatible: sortable is optional.
 */
var FlipbookGallery = window.FlipbookGallery || {};
"use strict";
jQuery.extend(FlipbookGallery, {

    initUploader: function () {
        // jQuery UI sortable may be absent in Joomla 6 admin. Do not break uploader init.
        if (jQuery.fn && typeof jQuery.fn.sortable === 'function') {
            jQuery('#flipbook_gallery_files').sortable();
        }

        jQuery('#flipbook_gallery_files').find('li.media').each(function (i, el) {
            var uploader = jQuery(el);
            uploader.find('.delete_flipbook_image').off('click.flipbook').on('click.flipbook', function (event) {
                event.preventDefault();
                if (confirm('Are you sure?')) {
                    uploader.remove();

                    if (jQuery('#flipbook_gallery_files li.media').length <= 0) {
                        jQuery('#flipbook_gallery_files').find('li.empty').fadeIn();
                    }
                    FlipbookGallery.ui_add_log('File \' '+uploader.attr('data-name')+' \' deleted');
                }
            });
        });
    },

    ui_add_log: function (message, color) {
        var d = new Date();

        var dateString = (('0' + d.getHours())).slice(-2) + ':' +
            (('0' + d.getMinutes())).slice(-2) + ':' +
            (('0' + d.getSeconds())).slice(-2);

        color = (typeof color === 'undefined' ? 'muted' : color);

        var template = jQuery('#flipbook_gallery_debug_template').text();
        template = template.replace('%%date%%', dateString);
        template = template.replace('%%message%%', String(message));
        template = template.replace('%%color%%', color);

        jQuery('#flipbook_gallery_debug').find('li.empty').fadeOut();
        jQuery('#flipbook_gallery_debug').prepend(template);
    },

    ui_multi_add_file: function (id, file) {
        var uploader = jQuery('#flipbook_gallery_files_template').text();
        uploader = uploader.replace('%%filename%%', file.name);

        uploader = jQuery(uploader);
        uploader.prop('id', 'uploaderFile' + id);
        uploader.data('file-id', id);

        if (typeof FileReader !== 'undefined'){
            var reader = new FileReader();

            reader.onload = function (e) {
                uploader.find('img').attr('src', e.target.result);
            };
            reader.readAsDataURL(file);
        }

        uploader.attr('data-source', 'client');
        jQuery('#flipbook_gallery_files').prepend(uploader);
    },

    ui_multi_update_file_status: function (id, status, message) {
        jQuery('#uploaderFile' + id).find('span.status, span.text-muted').first().html(message).prop('class', 'status text-' + status);
    },

    ui_multi_update_file_progress: function (id, percent, color, active) {
        color = (typeof color === 'undefined' ? false : color);
        active = (typeof active === 'undefined' ? true : active);

        var bar = jQuery('#uploaderFile' + id).find('div.progress-bar');

        bar.width(percent + '%').attr('aria-valuenow', percent);
        bar.toggleClass('progress-bar-striped progress-bar-animated', active);

        if (percent === 0){
            bar.html('');
        } else {
            bar.html(percent + '%');
        }

        if (color !== false){
            bar.removeClass('bg-success bg-info bg-warning bg-danger');
            bar.addClass('bg-' + color);
        }
    },

    ui_multi_update_file_data: function (id, file) {
        var uploader = jQuery('#uploaderFile' + id);
        var safeName = file && file.name ? file.name : '';

        jQuery('#flipbook_gallery_files').find("[data-name='"+safeName.replace(/'/g, "\\'")+"']").not(uploader).remove();
        uploader.find('.filename').text(safeName);
        uploader.attr('data-name', safeName);
        uploader.find('.flipbook_gallery_url').val(safeName).attr('value', safeName);
        uploader.find('.flipbook_gallery_source').val('client').attr('value', 'client');
        uploader.find('.flipbook_image_featured').val(safeName).attr('value', safeName);

        if (jQuery('#flipbook_gallery_files').find('li.empty').is(':visible')) {
            uploader.find('.flipbook_image_featured').prop('checked', true).attr('checked','checked');
        }

        jQuery('#flipbook_gallery_files').find('li.empty').fadeOut();
        uploader.find('.delete_flipbook_image').off('click.flipbook').on('click.flipbook', function (event) {
            event.preventDefault();
            if (confirm('Are you sure?')) {
                uploader.remove();

                if (jQuery('#flipbook_gallery_files li.media').length <= 0) {
                    jQuery('#flipbook_gallery_files').find('li.empty').fadeIn();
                }
                FlipbookGallery.ui_add_log('File \' '+safeName+' \' deleted');
            }
        });
    }
});
