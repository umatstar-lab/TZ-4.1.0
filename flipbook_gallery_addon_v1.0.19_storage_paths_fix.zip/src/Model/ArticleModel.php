<?php
/*------------------------------------------------------------------------
# Flipbook Gallery Addon for TZ Portfolio 4 / Joomla 6
-------------------------------------------------------------------------*/

namespace TemPlaza\Component\TZ_Portfolio\AddOn\Mediatype\Flipbook_gallery\Site\Model;

defined('_JEXEC') or die;

use TemPlaza\Component\TZ_Portfolio\Administrator\Library\AddOn\AddOnItemModel;

class ArticleModel extends AddOnItemModel
{
}
