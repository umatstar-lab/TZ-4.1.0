<?php
/*------------------------------------------------------------------------
# TZ Portfolio Extension
-------------------------------------------------------------------------*/
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\DI\Container;
use Joomla\Event\DispatcherInterface;
use Joomla\DI\ServiceProviderInterface;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\Extension\Service\Provider\MVCFactory;
use Joomla\CMS\Extension\Service\Provider\ComponentDispatcherFactory;
use TemPlaza\Component\TZ_Portfolio\AddOn\Mediatype\Flipbook_gallery\Extension\Flipbook_gallery;
use TemPlaza\Component\TZ_Portfolio\Administrator\Library\Helper\AddonHelper;
use TemPlaza\Component\TZ_Portfolio\Administrator\Library\AddOn\AddOnInterFace;

return new class () implements ServiceProviderInterface {
    public function register(Container $container)
    {
        $container->registerServiceProvider(new MVCFactory('\\TemPlaza\\Component\\TZ_Portfolio\\AddOn\\Mediatype\\Flipbook_gallery'));
        $container->registerServiceProvider(new ComponentDispatcherFactory('\\TemPlaza\\Component\\TZ_Portfolio\\AddOn\\Mediatype\\Flipbook_gallery'));

        $container->set(
            AddOnInterFace::class,
            function (Container $container) {
                $addon = new Flipbook_gallery(
                    $container->get(DispatcherInterface::class),
                    (array) AddonHelper::getAddOn('mediatype', 'flipbook_gallery')
                );

                $addon->setApplication(Factory::getApplication());
                $addon->setMVCFactory($container->get(MVCFactoryInterface::class));

                return $addon;
            }
        );
    }
};
