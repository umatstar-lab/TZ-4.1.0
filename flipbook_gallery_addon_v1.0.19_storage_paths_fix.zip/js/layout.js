/* Layout integration for TZ Portfolio flipbooks, scoped to pages containing a book. */
(function ($) {
    'use strict';
    var states = new WeakMap();
    function prepare(book) {
        var page = book.closest('.tp-item-page, .item-page, article');
        if (!page) return;
        page.classList.add('tz-flipbook-page');
        for (var p = book.parentElement; p && p !== document.body; p = p.parentElement) {
            p.classList.add('tz-flipbook-shrink');
        }
    }
    function attach(book) {
        if (states.has(book)) return;
        prepare(book);
        var wrap = book.closest('.tz-flipbook-gallery-wrap');
        var page = book.closest('.tz-flipbook-page');
        if (!wrap || !page) return;
        var state = {frame: 0, width: 0};
        states.set(book, state);
        function sync() {
            state.frame = 0;
            var parent = wrap.parentElement;
            var style = getComputedStyle(parent);
            var available = parent.clientWidth - (parseFloat(style.paddingLeft) || 0) - (parseFloat(style.paddingRight) || 0);
            var left = wrap.getBoundingClientRect().left;
            var width = Math.max(0, Math.min(available, document.documentElement.clientWidth - left - 4));
            var wanted = width.toFixed(2) + 'px';
            if (wrap.style.maxWidth !== wanted) wrap.style.maxWidth = wanted;
            var shell = book.parentElement;
            var inner = $(shell).width();
            if (Math.abs(inner - state.width) > 0.5) {
                state.width = inner;
                if ($(book).data('booklet')) $(window).triggerHandler('resize.booklet');
            }
            var rect = book.getBoundingClientRect();
            var outer = wrap.getBoundingClientRect();
            wrap.style.setProperty('--tz-book-left', (rect.left - outer.left) + 'px');
            wrap.style.setProperty('--tz-book-width', rect.width + 'px');
        }
        function schedule() { if (!state.frame) state.frame = requestAnimationFrame(sync); }
        state.schedule = schedule;
        if (window.ResizeObserver) {
            state.observer = new ResizeObserver(schedule);
            state.observer.observe(wrap.parentElement);
            state.observer.observe(book.parentElement);
        }
        $(book).on('bookletchange.tzLayout', schedule);
        window.addEventListener('resize', schedule);
        window.addEventListener('load', schedule, {once: true});
        if (document.fonts && document.fonts.ready) document.fonts.ready.then(schedule);
        schedule();
    }
    window.TZFlipbookLayout = {prepare: prepare, attach: attach};
    $(function () { document.querySelectorAll('.tz_portfolio_flipbook_gallery').forEach(function (book) { prepare(book); attach(book); }); });
})(jQuery);
