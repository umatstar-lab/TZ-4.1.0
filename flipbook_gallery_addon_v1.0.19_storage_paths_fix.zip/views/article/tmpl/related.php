<?php
/*------------------------------------------------------------------------
# Flipbook Gallery Addon for TZ Portfolio 4 / Joomla 6
-------------------------------------------------------------------------*/

defined('_JEXEC') or die;

use Joomla\Filesystem\File;
use TemPlaza\Component\TZ_Portfolio\Site\Helper\ArticleHelper;

$item = $this->item;
$gallery = $this->flipbook_gallery;
$params = $this->params;

$getParam = function($name, $default = null) {
    return method_exists($this, 'getFlipbookParam') ? $this->getFlipbookParam($name, $default) : $default;
};

if (!$item || !$gallery || !isset($gallery->data) || !is_array($gallery->data) || !count($gallery->data)) {
    return;
}

if ((int) $getParam('mt_flipbook_gallery_related_show_image', 1) !== 1) {
    return;
}

$image = !empty($gallery->featured) ? (string) $gallery->featured : (string) $gallery->data[0];
$image = basename($image);
if ($image === '') {
    return;
}

$imageSize = $getParam('mt_flipbook_gallery_related_size', 'o') ?: 'o';
$basePathNew = 'images/tz_portfolio/flipbook_gallery/' . (int) $item->id . '/';
$basePathLegacy = 'images/tz_portfolio_plus/flipbook_gallery/' . (int) $item->id . '/';
$basePath = File::exists(JPATH_ROOT . '/' . $basePathNew . $image) ? $basePathNew : $basePathLegacy;

if ($imageSize !== 'o') {
    $path = $basePath . 'resize/' . File::stripExt($image) . '_' . $imageSize . '.' . File::getExt($image);
    if (!File::exists(JPATH_ROOT . '/' . $path)) {
        $path = $basePath . $image;
    }
} else {
    $path = $basePath . $image;
}

$path = ArticleHelper::convertImageLegacy($path);
?>
<a href="<?php echo isset($item->link) ? $item->link : '#'; ?>">
    <img src="<?php echo $path; ?>"
         alt="<?php echo htmlspecialchars($item->title ?? '', ENT_COMPAT, 'UTF-8'); ?>"
         title="<?php echo htmlspecialchars($item->title ?? '', ENT_COMPAT, 'UTF-8'); ?>"
         itemprop="thumbnailUrl" />
</a>
